import { GoogleGenAI } from "@google/genai";
import { PROPERTIES } from "../constants";

// Initialize Gemini Client
// IMPORTANT: process.env.API_KEY must be available in the environment
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_INSTRUCTION = `
You are "HassBot", a knowledgeable and professional real estate virtual assistant for "Hass Quality Properties" in Uganda.
Your goal is to assist users in finding properties, understanding the Ugandan real estate market (Kampala, Entebbe, Wakiso, Mukono), and answering questions about buying, selling, or renting.

Here is the current list of featured properties available on the website:
${JSON.stringify(PROPERTIES.map(p => ({
  title: p.title,
  price: `${p.currency} ${p.price}`,
  location: p.location,
  type: p.type,
  id: p.id
})))}

Rules:
1. Always be polite, professional, and helpful.
2. If a user asks about available properties, reference the specific properties in the list above.
3. If the user asks for something not in the list, suggest they contact our sales team at sales@hassproperties.co.ug or +256 700 000 000.
4. Prices are often in UGX (Ugandan Shillings) or USD.
5. Keep responses concise (under 150 words) unless detailed analysis is requested.
6. Emphasize "Quality" and "Trust" as they are core values of Hass Quality Properties.
`;

export const sendMessageToGemini = async (history: { role: 'user' | 'model', text: string }[], message: string): Promise<string> => {
  try {
    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.text }]
      }))
    });

    const result = await chat.sendMessage({ message });
    return result.text || "I'm sorry, I couldn't generate a response at the moment. Please try again.";
  } catch (error) {
    console.error("Error communicating with Gemini:", error);
    return "I'm currently experiencing high traffic. Please try again later or contact our office directly.";
  }
};