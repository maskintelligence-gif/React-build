import React from 'react';
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-hass-blue text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div>
            <h2 className="text-2xl font-serif font-bold text-hass-gold mb-4">HASS QUALITY</h2>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              The premier real estate agency in Uganda. We connect you with the finest properties across Kampala, Entebbe, and beyond. Experience quality, trust, and professionalism.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-hass-gold hover:text-hass-blue transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-hass-gold hover:text-hass-blue transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-hass-gold hover:text-hass-blue transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4 border-b border-gray-700 pb-2 inline-block">Quick Links</h3>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><a href="#home" className="hover:text-hass-gold transition-colors">Home</a></li>
              <li><a href="#properties" className="hover:text-hass-gold transition-colors">Properties for Sale</a></li>
              <li><a href="#properties" className="hover:text-hass-gold transition-colors">Properties for Rent</a></li>
              <li><a href="#about" className="hover:text-hass-gold transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-hass-gold transition-colors">Terms of Service</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-bold mb-4 border-b border-gray-700 pb-2 inline-block">Contact Us</h3>
            <ul className="space-y-4 text-sm text-gray-400">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-hass-gold shrink-0" />
                <span>
                  Plot 15, Lugogo Bypass,<br />
                  Kampala, Uganda
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-hass-gold shrink-0" />
                <span>+256 700 123 456</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-hass-gold shrink-0" />
                <span>info@hassproperties.co.ug</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-bold mb-4 border-b border-gray-700 pb-2 inline-block">Newsletter</h3>
            <p className="text-gray-400 text-sm mb-4">Subscribe to get the latest property news and deals.</p>
            <form className="flex flex-col gap-2">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="bg-slate-800 border border-slate-700 text-white px-4 py-2 rounded focus:outline-none focus:border-hass-gold"
              />
              <button type="submit" className="bg-hass-gold hover:bg-yellow-600 text-hass-blue font-bold py-2 rounded transition-colors">
                Subscribe
              </button>
            </form>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-slate-800 pt-8 text-center text-gray-500 text-xs">
          <p>&copy; {new Date().getFullYear()} Hass Quality Properties. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;