import React, { useState, useRef } from 'react';
import { Property } from '../types';
import { supabase } from '../lib/supabaseClient';
import { 
  LayoutDashboard, 
  LogOut, 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  X,
  Image as ImageIcon,
  Save,
  Upload,
  Home,
  DollarSign,
  Key
} from 'lucide-react';
import { formatCurrency, getConvertedPrice } from '../constants';

interface AdminDashboardProps {
  userEmail: string;
  properties: Property[];
  onUpdateProperties: (properties: Property[]) => void;
  onLogout: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  userEmail, 
  properties, 
  onUpdateProperties,
  onLogout 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  
  // Stats
  const totalProperties = properties.length;
  const saleProperties = properties.filter(p => p.type === 'Sale').length;
  const rentProperties = properties.filter(p => p.type === 'Rent').length;

  // Form State
  const [formData, setFormData] = useState<Partial<Property>>({});
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    onLogout();
  };

  const filteredProperties = properties.filter(p => 
    p.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const openModal = (property?: Property) => {
    if (property) {
      setEditingProperty(property);
      setFormData({ ...property });
    } else {
      setEditingProperty(null);
      setFormData({
        id: Math.random().toString(36).substr(2, 9),
        title: '',
        price: 0,
        currency: 'UGX',
        location: '',
        bedrooms: 0,
        bathrooms: 0,
        sqft: 0,
        type: 'Sale',
        category: 'Residential',
        imageUrl: 'https://picsum.photos/seed/new/800/600',
        description: '',
        features: []
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.price) return;

    if (editingProperty) {
      // Update existing
      const updatedList = properties.map(p => 
        p.id === editingProperty.id ? { ...p, ...formData } as Property : p
      );
      onUpdateProperties(updatedList);
    } else {
      // Add new
      const newProperty = { ...formData, id: Math.random().toString(36).substr(2, 9) } as Property;
      onUpdateProperties([...properties, newProperty]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this property? This action cannot be undone.')) {
      onUpdateProperties(properties.filter(p => p.id !== id));
    }
  };

  const handleFeatureChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const features = e.target.value.split(',').map(f => f.trim()).filter(f => f);
    setFormData({ ...formData, features });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, imageUrl: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-hass-blue text-white flex-shrink-0 hidden md:flex flex-col shadow-xl z-20">
        <div className="p-6 border-b border-slate-700">
          <h2 className="font-serif font-bold text-xl text-hass-gold tracking-wide">HASS ADMIN</h2>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          <a href="#" className="flex items-center gap-3 px-4 py-3 bg-slate-800 text-hass-gold rounded-lg shadow-inner">
            <LayoutDashboard className="w-5 h-5" />
            <span className="font-medium">Dashboard</span>
          </a>
        </nav>

        <div className="p-4 border-t border-slate-700 bg-slate-900/50">
          <div className="mb-4 px-2">
             <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">Signed in as</p>
             <p className="text-sm font-medium truncate text-white">{userEmail}</p>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-4 py-2 text-gray-300 hover:text-white hover:bg-red-600/20 rounded-lg transition-colors duration-200"
          >
            <LogOut className="w-5 h-5" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        {/* Mobile Header */}
        <header className="bg-white shadow-sm p-4 flex justify-between items-center md:hidden z-10">
          <h1 className="font-serif font-bold text-hass-blue">Hass Admin</h1>
          <button onClick={handleLogout} className="text-slate-600">
            <LogOut className="w-5 h-5" />
          </button>
        </header>

        <div className="flex-1 overflow-auto p-4 md:p-8 space-y-8">
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between">
                <div>
                    <p className="text-gray-500 text-sm font-medium mb-1">Total Properties</p>
                    <h3 className="text-3xl font-bold text-hass-blue">{totalProperties}</h3>
                </div>
                <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center">
                    <Home className="w-6 h-6 text-hass-blue" />
                </div>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between">
                <div>
                    <p className="text-gray-500 text-sm font-medium mb-1">For Sale</p>
                    <h3 className="text-3xl font-bold text-green-600">{saleProperties}</h3>
                </div>
                <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-green-600" />
                </div>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between">
                <div>
                    <p className="text-gray-500 text-sm font-medium mb-1">For Rent</p>
                    <h3 className="text-3xl font-bold text-hass-gold">{rentProperties}</h3>
                </div>
                <div className="w-12 h-12 bg-yellow-50 rounded-full flex items-center justify-center">
                    <Key className="w-6 h-6 text-hass-gold" />
                </div>
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <h2 className="text-xl md:text-2xl font-bold text-slate-800">Property Listings</h2>
            <button 
              onClick={() => openModal()}
              className="bg-hass-blue hover:bg-slate-800 text-white px-6 py-2.5 rounded-lg font-bold flex items-center gap-2 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              <Plus className="w-5 h-5" /> Add Property
            </button>
          </div>

          {/* Search & Filter Bar */}
          <div className="bg-white p-2 rounded-xl shadow-sm border border-gray-100 flex items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                type="text" 
                placeholder="Search by title, location..." 
                className="w-full pl-10 pr-4 py-3 bg-transparent focus:outline-none text-gray-700 placeholder-gray-400"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          {/* Table */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-gray-50/50 border-b border-gray-100 text-gray-500 text-xs font-semibold uppercase tracking-wider">
                    <th className="p-4 pl-6">Property Details</th>
                    <th className="p-4">Location</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Price</th>
                    <th className="p-4 pr-6 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filteredProperties.map(property => {
                     const converted = getConvertedPrice(property.price, property.currency);
                     return (
                      <tr key={property.id} className="hover:bg-blue-50/30 transition-colors group">
                        <td className="p-4 pl-6">
                          <div className="flex items-center gap-4">
                            <div className="w-16 h-16 rounded-lg overflow-hidden shrink-0 border border-gray-200">
                                <img src={property.imageUrl} alt="" className="w-full h-full object-cover" />
                            </div>
                            <div>
                                <p className="font-semibold text-slate-900 line-clamp-1">{property.title}</p>
                                <p className="text-xs text-gray-500 mt-0.5">{property.category} • {property.sqft} sqft</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 text-sm text-gray-600">{property.location}</td>
                        <td className="p-4">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            property.type === 'Sale' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-amber-100 text-amber-800'
                          }`}>
                            {property.type}
                          </span>
                        </td>
                        <td className="p-4 text-sm">
                            <div className="font-medium text-slate-700">{formatCurrency(property.price, property.currency)}</div>
                            <div className="text-xs text-gray-400 mt-0.5">≈ {formatCurrency(converted.amount, converted.currency)}</div>
                        </td>
                        <td className="p-4 pr-6 text-right">
                          <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button 
                              onClick={() => openModal(property)}
                              className="p-2 text-slate-400 hover:text-hass-blue hover:bg-blue-50 rounded-lg transition-colors"
                              title="Edit"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => handleDelete(property.id)}
                              className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                              title="Delete"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {filteredProperties.length === 0 && (
              <div className="py-12 flex flex-col items-center justify-center text-gray-400">
                <Search className="w-12 h-12 mb-3 opacity-20" />
                <p>No properties found matching your search.</p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Modern Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl my-8 animate-fade-in-up">
            <form onSubmit={handleSave}>
              <div className="p-6 border-b border-gray-100 flex justify-between items-center sticky top-0 bg-white z-10 rounded-t-2xl">
                <div>
                    <h3 className="text-xl font-bold text-slate-800">
                    {editingProperty ? 'Edit Property' : 'Add New Property'}
                    </h3>
                    <p className="text-sm text-gray-500">Fill in the details below to update the listing.</p>
                </div>
                <button type="button" onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600 p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="p-8 space-y-8 max-h-[75vh] overflow-y-auto">
                
                {/* Section 1: Image */}
                <div className="space-y-4">
                    <label className="block text-sm font-semibold text-gray-700">Property Image</label>
                    <div className="flex flex-col md:flex-row gap-6 items-start">
                        <div 
                            onClick={() => fileInputRef.current?.click()}
                            className="flex-1 w-full h-64 border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-hass-blue hover:bg-blue-50/50 transition-all group relative overflow-hidden bg-gray-50"
                        >
                            {formData.imageUrl ? (
                                <>
                                    <img src={formData.imageUrl} alt="Preview" className="w-full h-full object-cover" />
                                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                        <p className="text-white font-medium flex items-center gap-2"><Upload className="w-5 h-5" /> Change Image</p>
                                    </div>
                                </>
                            ) : (
                                <div className="text-center p-6">
                                    <div className="w-12 h-12 bg-blue-100 text-hass-blue rounded-full flex items-center justify-center mx-auto mb-3">
                                        <ImageIcon className="w-6 h-6" />
                                    </div>
                                    <p className="text-sm font-medium text-gray-700">Click to upload image</p>
                                    <p className="text-xs text-gray-400 mt-1">SVG, PNG, JPG or GIF</p>
                                </div>
                            )}
                            <input 
                                type="file" 
                                ref={fileInputRef}
                                className="hidden" 
                                accept="image/*"
                                onChange={handleImageUpload}
                            />
                        </div>
                        <div className="w-full md:w-1/3 space-y-3">
                             <label className="text-xs font-semibold text-gray-500 uppercase">Or use URL</label>
                             <input 
                                type="text" 
                                placeholder="https://example.com/image.jpg"
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-hass-blue outline-none text-sm"
                                value={formData.imageUrl || ''}
                                onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
                              />
                              <p className="text-xs text-gray-400 leading-relaxed">
                                Uploading an image directly is recommended. The image will be previewed instantly.
                              </p>
                        </div>
                    </div>
                </div>

                <div className="border-t border-gray-100 my-6"></div>

                {/* Section 2: Basic Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Property Title</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Luxury Villa in Kololo"
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-hass-blue outline-none transition-shadow"
                      value={formData.title || ''}
                      onChange={(e) => setFormData({...formData, title: e.target.value})}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Price</label>
                    <div className="relative">
                        <input 
                        type="number" 
                        required
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-hass-blue outline-none transition-shadow"
                        value={formData.price || ''}
                        onChange={(e) => setFormData({...formData, price: Number(e.target.value)})}
                        />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Currency</label>
                    <select 
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-hass-blue outline-none bg-white"
                      value={formData.currency || 'UGX'}
                      onChange={(e) => setFormData({...formData, currency: e.target.value as 'UGX' | 'USD'})}
                    >
                      <option value="UGX">UGX (Shillings)</option>
                      <option value="USD">USD (Dollars)</option>
                    </select>
                  </div>

                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Kololo, Kampala"
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-hass-blue outline-none transition-shadow"
                      value={formData.location || ''}
                      onChange={(e) => setFormData({...formData, location: e.target.value})}
                    />
                  </div>
                </div>

                <div className="border-t border-gray-100 my-6"></div>

                {/* Section 3: Details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                     <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select 
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-hass-blue outline-none bg-white"
                      value={formData.category || 'Residential'}
                      onChange={(e) => setFormData({...formData, category: e.target.value as any})}
                    >
                      <option value="Residential">Residential</option>
                      <option value="Commercial">Commercial</option>
                      <option value="Land">Land</option>
                    </select>
                  </div>

                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Listing Type</label>
                    <div className="flex gap-4">
                       <label className={`flex-1 flex items-center justify-center gap-2 p-2.5 border rounded-lg cursor-pointer transition-all ${formData.type === 'Sale' ? 'border-hass-blue bg-blue-50 text-hass-blue font-semibold' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                          <input 
                            type="radio" 
                            name="type" 
                            value="Sale" 
                            checked={formData.type === 'Sale'}
                            onChange={() => setFormData({...formData, type: 'Sale'})}
                            className="hidden"
                          />
                          <span>For Sale</span>
                       </label>
                       <label className={`flex-1 flex items-center justify-center gap-2 p-2.5 border rounded-lg cursor-pointer transition-all ${formData.type === 'Rent' ? 'border-hass-blue bg-blue-50 text-hass-blue font-semibold' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                          <input 
                            type="radio" 
                            name="type" 
                            value="Rent" 
                            checked={formData.type === 'Rent'}
                            onChange={() => setFormData({...formData, type: 'Rent'})}
                            className="hidden"
                          />
                          <span>For Rent</span>
                       </label>
                    </div>
                  </div>

                  {formData.category !== 'Land' && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Bedrooms</label>
                        <input 
                          type="number" 
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-hass-blue outline-none"
                          value={formData.bedrooms || 0}
                          onChange={(e) => setFormData({...formData, bedrooms: Number(e.target.value)})}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Bathrooms</label>
                        <input 
                          type="number" 
                          className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-hass-blue outline-none"
                          value={formData.bathrooms || 0}
                          onChange={(e) => setFormData({...formData, bathrooms: Number(e.target.value)})}
                        />
                      </div>
                    </>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Size (sqft/decimals)</label>
                    <input 
                      type="number" 
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-hass-blue outline-none"
                      value={formData.sqft || 0}
                      onChange={(e) => setFormData({...formData, sqft: Number(e.target.value)})}
                    />
                  </div>
                </div>

                <div className="border-t border-gray-100 my-6"></div>

                {/* Section 4: Description & Features */}
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <textarea 
                      rows={5}
                      placeholder="Describe the property, key features, neighborhood, etc."
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-hass-blue outline-none resize-none"
                      value={formData.description || ''}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                    ></textarea>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Features</label>
                    <p className="text-xs text-gray-500 mb-2">Separate features with commas (e.g. Pool, Garden, Security)</p>
                    <input 
                      type="text" 
                      placeholder="Pool, Gym, Security..."
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-hass-blue outline-none"
                      value={formData.features?.join(', ') || ''}
                      onChange={handleFeatureChange}
                    />
                    <div className="flex flex-wrap gap-2 mt-3">
                        {formData.features?.map((feature, i) => (
                            <span key={i} className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-xs font-medium">
                                {feature}
                            </span>
                        ))}
                    </div>
                  </div>
                </div>

              </div>

              <div className="p-6 border-t border-gray-100 bg-gray-50 rounded-b-2xl flex justify-end gap-3 sticky bottom-0 z-10">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="px-6 py-2.5 text-gray-600 hover:text-slate-800 font-medium transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-8 py-2.5 bg-hass-blue hover:bg-slate-800 text-white font-bold rounded-lg transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 flex items-center gap-2"
                >
                  <Save className="w-4 h-4" /> Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;