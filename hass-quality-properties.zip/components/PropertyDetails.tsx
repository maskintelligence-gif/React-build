import React, { useState, useEffect } from 'react';
import { Property } from '../types';
import { formatCurrency, getConvertedPrice } from '../constants';
import { 
  ArrowLeft, 
  Bed, 
  Bath, 
  Move, 
  MapPin, 
  Check, 
  Facebook, 
  Twitter, 
  MessageCircle,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  X,
  Download
} from 'lucide-react';

interface PropertyDetailsProps {
  property: Property;
  onBack: () => void;
}

const PropertyDetails: React.FC<PropertyDetailsProps> = ({ property, onBack }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Use property.images if available, otherwise fallback to property.imageUrl wrapped in array
  const galleryImages = property.images && property.images.length > 0 
    ? property.images 
    : [property.imageUrl];

  // Construct a shareable link.
  const shareUrl = `${window.location.origin}?propertyId=${property.id}`;
  const shareText = `Check out this amazing property: ${property.title} in ${property.location} for ${formatCurrency(property.price, property.currency)}`;

  const converted = getConvertedPrice(property.price, property.currency);

  // Handle ESC key to close fullscreen
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsFullscreen(false);
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, []);

  const handleShare = (platform: 'facebook' | 'twitter' | 'whatsapp') => {
    let url = '';
    switch (platform) {
      case 'facebook':
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
        break;
      case 'twitter':
        url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'whatsapp':
        url = `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`;
        break;
    }
    window.open(url, '_blank', 'width=600,height=400');
  };

  const nextImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setCurrentImageIndex((prev) => (prev === galleryImages.length - 1 ? 0 : prev + 1));
  };

  const prevImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setCurrentImageIndex((prev) => (prev === 0 ? galleryImages.length - 1 : prev - 1));
  };

  const selectImage = (index: number) => {
    setCurrentImageIndex(index);
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const downloadImage = async () => {
    const imageUrl = galleryImages[currentImageIndex];
    try {
        const response = await fetch(imageUrl);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        // Clean filename logic
        const ext = imageUrl.split('.').pop()?.split('?')[0] || 'jpg';
        // Limit extension length in case of weird URLs
        const safeExt = ext.length > 4 ? 'jpg' : ext;
        link.download = `hass-property-${property.id}-${currentImageIndex + 1}.${safeExt}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
    } catch (error) {
        console.error("Download failed, opening in new tab", error);
        window.open(imageUrl, '_blank');
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen pb-20 animate-fade-in-up">
      
      {/* Fullscreen Overlay */}
      {isFullscreen && (
        <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-md flex items-center justify-center animate-fade-in">
           {/* Top Controls */}
           <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center z-50 bg-gradient-to-b from-black/50 to-transparent">
              <div className="text-white font-medium text-lg drop-shadow-md">
                 {currentImageIndex + 1} / {galleryImages.length}
              </div>
              <div className="flex items-center gap-4">
                 <button 
                    onClick={downloadImage}
                    className="p-2 text-white/80 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition-all"
                    title="Download Image"
                 >
                    <Download className="w-6 h-6" />
                 </button>
                 <button 
                    onClick={toggleFullscreen}
                    className="p-2 text-white/80 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition-all"
                    title="Close"
                 >
                    <X className="w-8 h-8" />
                 </button>
              </div>
           </div>

           {/* Navigation Arrows */}
           <button 
              onClick={prevImage}
              className="absolute left-4 p-4 text-white/70 hover:text-hass-gold hover:scale-110 transition-all z-50"
           >
              <ChevronLeft className="w-10 h-10 drop-shadow-lg" />
           </button>
           <button 
              onClick={nextImage}
              className="absolute right-4 p-4 text-white/70 hover:text-hass-gold hover:scale-110 transition-all z-50"
           >
              <ChevronRight className="w-10 h-10 drop-shadow-lg" />
           </button>

           {/* Main Fullscreen Image */}
           <img 
              src={galleryImages[currentImageIndex]} 
              alt="Fullscreen view" 
              className="max-w-full max-h-screen object-contain p-4 select-none"
           />
        </div>
      )}

      {/* Hero Image Section / Gallery */}
      <div className="relative h-[60vh] md:h-[70vh] w-full bg-slate-900 group">
        
        {/* Main Image */}
        <div className="w-full h-full cursor-pointer" onClick={toggleFullscreen}>
            <img 
            src={galleryImages[currentImageIndex]} 
            alt={`${property.title} - View ${currentImageIndex + 1}`} 
            className="w-full h-full object-cover transition-opacity duration-500 ease-in-out hover:opacity-90" 
            />
        </div>
        
        {/* Overlay Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/70 pointer-events-none"></div>

        {/* Navigation Buttons */}
        <button 
            onClick={onBack}
            className="absolute top-24 left-4 md:left-8 bg-white/20 hover:bg-white/90 text-white hover:text-slate-900 px-4 py-2 rounded-full flex items-center gap-2 font-medium transition-all backdrop-blur-md z-20"
        >
            <ArrowLeft className="w-4 h-4" /> Back to Listings
        </button>

        {galleryImages.length > 1 && (
          <>
            <button 
              onClick={prevImage}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-hass-blue text-white p-3 rounded-full backdrop-blur-sm transition-all opacity-0 group-hover:opacity-100 focus:opacity-100 translate-x-[-20px] group-hover:translate-x-0 z-20"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button 
              onClick={nextImage}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-hass-blue text-white p-3 rounded-full backdrop-blur-sm transition-all opacity-0 group-hover:opacity-100 focus:opacity-100 translate-x-[20px] group-hover:translate-x-0 z-20"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </>
        )}

        {/* Image Controls Badge */}
        <div className="absolute top-24 right-4 md:right-8 flex gap-2 z-20">
             <button 
                onClick={downloadImage}
                className="bg-black/50 hover:bg-black/70 backdrop-blur-md text-white p-2 rounded-full transition-colors"
                title="Download"
            >
                <Download className="w-4 h-4" />
            </button>
             <button 
                onClick={toggleFullscreen}
                className="bg-black/50 hover:bg-black/70 backdrop-blur-md text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-2 transition-colors"
             >
                <Maximize2 className="w-3 h-3" />
                {currentImageIndex + 1} / {galleryImages.length}
            </button>
        </div>

        {/* Thumbnail Strip */}
        {galleryImages.length > 1 && (
          <div className="absolute bottom-28 left-0 right-0 z-20 px-4 flex justify-center pointer-events-none">
            <div className="flex gap-2 p-2 bg-black/40 backdrop-blur-md rounded-2xl overflow-x-auto max-w-full no-scrollbar pointer-events-auto">
              {galleryImages.map((img, index) => (
                <button
                  key={index}
                  onClick={() => selectImage(index)}
                  className={`relative w-16 h-12 md:w-20 md:h-16 rounded-lg overflow-hidden shrink-0 transition-all border-2 ${
                    currentImageIndex === index ? 'border-hass-gold opacity-100 scale-105' : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt={`Thumbnail ${index + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="container mx-auto px-4 -mt-20 relative z-30">
        <div className="bg-white rounded-xl shadow-xl p-6 md:p-10">
            
            {/* Header Info */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
                <div>
                    <div className="flex items-center gap-2 mb-2">
                        <span className="bg-hass-gold text-hass-blue text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                            {property.type}
                        </span>
                        <span className="bg-slate-100 text-slate-600 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                            {property.category}
                        </span>
                    </div>
                    <h1 className="text-3xl md:text-4xl font-serif font-bold text-hass-blue mb-2">{property.title}</h1>
                    <div className="flex items-center text-gray-500">
                        <MapPin className="w-5 h-5 mr-2 text-hass-accent" />
                        <span className="text-lg">{property.location}</span>
                    </div>
                </div>
                <div className="text-left md:text-right">
                    <p className="text-3xl font-bold text-hass-gold">{formatCurrency(property.price, property.currency)}</p>
                    <p className="text-lg font-medium text-gray-400">
                        ≈ {formatCurrency(converted.amount, converted.currency)}
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                        {property.type === 'Rent' ? '/ Month' : ' Asking Price'}
                    </p>
                </div>
            </div>

            {/* Key Features Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-8 border-y border-gray-100 mb-8">
                <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg">
                    <Bed className="w-6 h-6 text-hass-blue mb-2" />
                    <span className="font-bold text-xl">{property.bedrooms}</span>
                    <span className="text-xs text-gray-500 uppercase tracking-wide">Bedrooms</span>
                </div>
                <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg">
                    <Bath className="w-6 h-6 text-hass-blue mb-2" />
                    <span className="font-bold text-xl">{property.bathrooms}</span>
                    <span className="text-xs text-gray-500 uppercase tracking-wide">Bathrooms</span>
                </div>
                <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg">
                    <Move className="w-6 h-6 text-hass-blue mb-2" />
                    <span className="font-bold text-xl">{property.sqft.toLocaleString()}</span>
                    <span className="text-xs text-gray-500 uppercase tracking-wide">Square Ft</span>
                </div>
                <div className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg">
                    <Check className="w-6 h-6 text-hass-blue mb-2" />
                    <span className="font-bold text-xl">Ready</span>
                    <span className="text-xs text-gray-500 uppercase tracking-wide">Status</span>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                {/* Description & Features */}
                <div className="lg:col-span-2 space-y-8">
                    <div>
                        <h2 className="text-2xl font-serif font-bold text-hass-blue mb-4">Description</h2>
                        <p className="text-gray-600 leading-relaxed text-lg">
                            {property.description}
                        </p>
                    </div>

                    <div>
                        <h2 className="text-2xl font-serif font-bold text-hass-blue mb-4">Property Features</h2>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                            {property.features.map((feature, idx) => (
                                <div key={idx} className="flex items-center gap-3 text-gray-700 p-3 bg-gray-50 rounded-lg">
                                    <div className="w-2 h-2 bg-hass-gold rounded-full"></div>
                                    {feature}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Sidebar / Social Share */}
                <div className="space-y-8">
                    <div className="bg-white border border-gray-200 p-6 rounded-xl shadow-sm">
                         <h3 className="font-serif font-bold text-xl text-hass-blue mb-4">Share this Property</h3>
                         <div className="flex flex-col gap-3">
                            <button 
                                onClick={() => handleShare('facebook')}
                                className="w-full bg-[#1877F2] hover:bg-[#166fe5] text-white py-3 px-4 rounded-lg flex items-center justify-center gap-3 transition-colors font-medium"
                            >
                                <Facebook className="w-5 h-5" /> Share on Facebook
                            </button>
                            <button 
                                onClick={() => handleShare('twitter')}
                                className="w-full bg-[#1DA1F2] hover:bg-[#1a94df] text-white py-3 px-4 rounded-lg flex items-center justify-center gap-3 transition-colors font-medium"
                            >
                                <Twitter className="w-5 h-5" /> Share on Twitter
                            </button>
                            <button 
                                onClick={() => handleShare('whatsapp')}
                                className="w-full bg-[#25D366] hover:bg-[#20bd5a] text-white py-3 px-4 rounded-lg flex items-center justify-center gap-3 transition-colors font-medium"
                            >
                                <MessageCircle className="w-5 h-5" /> Share on WhatsApp
                            </button>
                         </div>
                    </div>

                    <div className="bg-hass-blue text-white p-6 rounded-xl shadow-lg">
                        <h3 className="font-serif font-bold text-xl mb-2">Interested?</h3>
                        <p className="text-gray-300 text-sm mb-6">Contact our agents to schedule a viewing.</p>
                        <button className="w-full bg-hass-gold hover:bg-yellow-600 text-hass-blue font-bold py-3 rounded-lg transition-colors">
                            Request Viewing
                        </button>
                    </div>
                </div>
            </div>

        </div>
      </div>
    </div>
  );
};

export default PropertyDetails;