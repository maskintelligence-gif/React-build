import React, { useState } from 'react';
import { Menu, X, Home, Phone, Info, Grid } from 'lucide-react';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-hass-blue text-white shadow-lg">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          <div className="bg-hass-gold p-2 rounded-lg">
            <Home className="text-hass-blue w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold font-serif tracking-wide text-hass-gold">HASS QUALITY</h1>
            <p className="text-xs text-gray-400 tracking-widest uppercase">Properties</p>
          </div>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex space-x-8 text-sm font-medium">
          <a href="#home" className="hover:text-hass-gold transition-colors">Home</a>
          <a href="#properties" className="hover:text-hass-gold transition-colors">Properties</a>
          <a href="#about" className="hover:text-hass-gold transition-colors">About Us</a>
          <a href="#contact" className="hover:text-hass-gold transition-colors">Contact</a>
        </nav>

        {/* Call to Action */}
        <div className="hidden md:block">
          <a href="#contact" className="bg-hass-gold hover:bg-yellow-600 text-hass-blue px-5 py-2 rounded-full font-semibold transition-colors">
            List Your Property
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="md:hidden bg-slate-800 border-t border-slate-700">
          <nav className="flex flex-col p-4 space-y-4">
            <a href="#home" className="flex items-center space-x-2 text-gray-300 hover:text-white" onClick={() => setIsOpen(false)}>
              <Home className="w-4 h-4" /> <span>Home</span>
            </a>
            <a href="#properties" className="flex items-center space-x-2 text-gray-300 hover:text-white" onClick={() => setIsOpen(false)}>
              <Grid className="w-4 h-4" /> <span>Properties</span>
            </a>
            <a href="#about" className="flex items-center space-x-2 text-gray-300 hover:text-white" onClick={() => setIsOpen(false)}>
              <Info className="w-4 h-4" /> <span>About Us</span>
            </a>
            <a href="#contact" className="flex items-center space-x-2 text-gray-300 hover:text-white" onClick={() => setIsOpen(false)}>
              <Phone className="w-4 h-4" /> <span>Contact</span>
            </a>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;