import React from 'react';
import { Property } from '../types';
import { formatCurrency, getConvertedPrice } from '../constants';
import { Bed, Bath, Move, MapPin } from 'lucide-react';

interface PropertyCardProps {
  property: Property;
  onSelect: (property: Property) => void;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property, onSelect }) => {
  const converted = getConvertedPrice(property.price, property.currency);
  
  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden group border border-gray-100 flex flex-col h-full">
      {/* Image Container */}
      <div className="relative h-64 overflow-hidden cursor-pointer" onClick={() => onSelect(property)}>
        <img 
          src={property.imageUrl} 
          alt={property.title} 
          className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4 bg-hass-gold text-hass-blue text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
          {property.type}
        </div>
        
        {/* Dual Price Overlay */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent p-4 pt-12">
           <div className="flex flex-col">
              <span className="text-white font-bold text-xl leading-tight">
                {formatCurrency(property.price, property.currency)}
              </span>
              <span className="text-gray-300 text-sm font-medium">
                ≈ {formatCurrency(converted.amount, converted.currency)}
              </span>
           </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-5 flex-grow flex flex-col">
        <div className="flex items-start justify-between mb-2">
            <div>
                <h3 
                  className="text-lg font-bold text-slate-800 line-clamp-1 hover:text-hass-gold cursor-pointer transition-colors"
                  onClick={() => onSelect(property)}
                >
                  {property.title}
                </h3>
                <div className="flex items-center text-gray-500 text-sm mt-1">
                <MapPin className="w-4 h-4 mr-1 text-hass-accent" />
                {property.location}
                </div>
            </div>
        </div>

        <div className="flex items-center justify-between mt-4 py-4 border-t border-gray-100 text-gray-600 text-sm">
          {property.category !== 'Land' && (
            <>
              <div className="flex items-center gap-1">
                <Bed className="w-4 h-4" />
                <span>{property.bedrooms} Beds</span>
              </div>
              <div className="flex items-center gap-1">
                <Bath className="w-4 h-4" />
                <span>{property.bathrooms} Baths</span>
              </div>
            </>
          )}
          <div className="flex items-center gap-1">
            <Move className="w-4 h-4" />
            <span>{property.sqft.toLocaleString()} sqft</span>
          </div>
        </div>
        
        <div className="mt-auto pt-2">
          <button 
            onClick={() => onSelect(property)}
            className="w-full bg-slate-100 hover:bg-hass-blue hover:text-white text-slate-700 font-medium py-2 rounded-lg transition-colors duration-300"
          >
              View Details
          </button>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;