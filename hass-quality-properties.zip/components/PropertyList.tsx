import React from 'react';
import { Property, FilterType, PriceRangeOption } from '../types';
import PropertyCard from './PropertyCard';
import { PRICE_RANGES, EXCHANGE_RATE_USD_TO_UGX } from '../constants';
import { Filter, ChevronDown, Search } from 'lucide-react';

interface PropertyListProps {
  properties: Property[];
  onSelectProperty: (property: Property) => void;
  filters: {
    keyword: string;
    location: string;
    type: FilterType;
    price: PriceRangeOption;
  };
  onFilterChange: (filters: Partial<PropertyListProps['filters']>) => void;
}

const PropertyList: React.FC<PropertyListProps> = ({ properties, onSelectProperty, filters, onFilterChange }) => {
  const { keyword, location, type: activeFilter, price: priceFilter } = filters;

  const filteredProperties = properties.filter(prop => {
    // 1. Keyword Filter
    if (keyword && !prop.title.toLowerCase().includes(keyword.toLowerCase()) && !prop.description.toLowerCase().includes(keyword.toLowerCase())) {
        return false;
    }

    // 2. Location Filter
    if (location && !prop.location.toLowerCase().includes(location.toLowerCase())) {
        return false;
    }

    // 3. Category/Type Filter
    let matchesCategory = true;
    if (activeFilter !== FilterType.ALL) {
      if (activeFilter === FilterType.LAND) {
        matchesCategory = prop.category === 'Land';
      } else {
        matchesCategory = prop.type === activeFilter;
      }
    }

    // 4. Price Filter Logic
    let matchesPrice = true;
    if (priceFilter.label !== 'Any Price') {
      // Normalize property price to the filter's currency
      let propPriceInFilterCurrency = prop.price;
      
      if (prop.currency !== priceFilter.currency) {
        if (priceFilter.currency === 'UGX') {
          // Prop is USD, filter is UGX -> Convert USD to UGX
          propPriceInFilterCurrency = prop.price * EXCHANGE_RATE_USD_TO_UGX;
        } else {
          // Prop is UGX, filter is USD -> Convert UGX to USD
          propPriceInFilterCurrency = prop.price / EXCHANGE_RATE_USD_TO_UGX;
        }
      }

      if (priceFilter.min && propPriceInFilterCurrency < priceFilter.min) {
        matchesPrice = false;
      }
      if (priceFilter.max && propPriceInFilterCurrency > priceFilter.max) {
        matchesPrice = false;
      }
    }

    return matchesCategory && matchesPrice;
  });

  return (
    <section id="properties" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-hass-blue mb-4">Featured Listings</h2>
          <div className="w-20 h-1 bg-hass-gold mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore our curated selection of exclusive properties across Uganda's most sought-after locations.
          </p>
        </div>

        {/* Filters Container */}
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 mb-12 flex flex-col md:flex-row justify-between items-center gap-6 max-w-4xl mx-auto">
          
          {/* Type Filters (Pills) */}
          <div className="flex gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 no-scrollbar">
            {Object.values(FilterType).map((filter) => (
              <button
                key={filter}
                onClick={() => onFilterChange({ type: filter })}
                className={`px-5 py-2 rounded-full text-sm font-semibold transition-all whitespace-nowrap ${
                  activeFilter === filter
                    ? 'bg-hass-blue text-white shadow-md'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          {/* Price Filter (Dropdown) */}
          <div className="relative w-full md:w-64">
             <div className="relative">
                <select 
                  className="w-full appearance-none bg-gray-50 border border-gray-200 text-gray-700 py-3 pl-10 pr-8 rounded-xl focus:outline-none focus:ring-2 focus:ring-hass-blue/20 cursor-pointer font-medium text-sm"
                  onChange={(e) => {
                    const selected = PRICE_RANGES.find(r => r.label === e.target.value);
                    if (selected) onFilterChange({ price: selected });
                  }}
                  value={priceFilter.label}
                >
                  {PRICE_RANGES.map((range, index) => (
                    <option key={index} value={range.label}>{range.label}</option>
                  ))}
                </select>
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <Filter className="w-4 h-4 text-hass-gold" />
                </div>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </div>
             </div>
          </div>
        </div>

        {/* Active Search Filters Display */}
        {(keyword || location) && (
            <div className="flex flex-wrap gap-2 mb-8 justify-center">
                {keyword && (
                    <span className="bg-hass-blue/10 text-hass-blue px-3 py-1 rounded-full text-sm flex items-center gap-1">
                        Keyword: {keyword} <button onClick={() => onFilterChange({ keyword: '' })} className="hover:text-red-500">×</button>
                    </span>
                )}
                {location && (
                    <span className="bg-hass-blue/10 text-hass-blue px-3 py-1 rounded-full text-sm flex items-center gap-1">
                        Location: {location} <button onClick={() => onFilterChange({ location: '' })} className="hover:text-red-500">×</button>
                    </span>
                )}
                 <button onClick={() => onFilterChange({ keyword: '', location: '', type: FilterType.ALL, price: PRICE_RANGES[0] })} className="text-sm text-gray-500 underline hover:text-hass-gold ml-2">
                    Clear All
                 </button>
            </div>
        )}

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProperties.map(property => (
            <PropertyCard 
              key={property.id} 
              property={property} 
              onSelect={onSelectProperty}
            />
          ))}
        </div>

        {filteredProperties.length === 0 && (
          <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-gray-200">
            <div className="flex flex-col items-center justify-center text-gray-400">
              <Search className="w-12 h-12 mb-4 text-gray-300" />
              <p className="text-lg font-medium text-gray-600">No properties match your criteria.</p>
              <button 
                onClick={() => onFilterChange({ type: FilterType.ALL, price: PRICE_RANGES[0], keyword: '', location: '' })}
                className="mt-4 text-hass-gold hover:underline font-medium"
              >
                Clear all filters
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default PropertyList;