import React, { useState } from 'react';
import { Search, MapPin, Home } from 'lucide-react';
import { FilterType } from '../types';

interface HeroProps {
  onSearch: (filters: { keyword: string; location: string; type: FilterType | '' }) => void;
}

const Hero: React.FC<HeroProps> = ({ onSearch }) => {
  const [keyword, setKeyword] = useState('');
  const [location, setLocation] = useState('');
  const [type, setType] = useState<FilterType | ''>('');

  const handleSearchClick = () => {
    onSearch({ keyword, location, type });
    // Smooth scroll to properties section
    const propertiesSection = document.getElementById('properties');
    if (propertiesSection) {
      propertiesSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/seed/kampala_skyline/1920/1080" 
          alt="Kampala Skyline" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-hass-blue/70 mix-blend-multiply"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6 animate-fade-in-up">
          Discover Premium Real Estate <br/> <span className="text-hass-gold">In Uganda</span>
        </h1>
        <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
          From luxury villas in Kololo to commercial spaces in Kampala CBD. 
          Hass Quality Properties is your trusted partner.
        </p>

        {/* Search Bar */}
        <div className="bg-white p-2 rounded-lg shadow-2xl max-w-4xl mx-auto flex flex-col md:flex-row gap-2">
          
          {/* Keyword Input */}
          <div className="flex-1 flex items-center px-4 border-b md:border-b-0 md:border-r border-gray-200 py-2 md:py-0">
            <Search className="text-gray-400 w-5 h-5 mr-3 shrink-0" />
            <input 
              type="text" 
              placeholder="Keyword..." 
              className="w-full py-3 focus:outline-none text-gray-700 bg-transparent"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearchClick()}
            />
          </div>

          {/* Location Dropdown */}
          <div className="flex-1 flex items-center px-4 border-b md:border-b-0 md:border-r border-gray-200 py-2 md:py-0">
            <MapPin className="text-gray-400 w-5 h-5 mr-3 shrink-0" />
            <select 
              className="w-full py-3 focus:outline-none text-gray-700 bg-transparent cursor-pointer"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            >
              <option value="">All Locations</option>
              <option value="Kampala">Kampala</option>
              <option value="Entebbe">Entebbe</option>
              <option value="Wakiso">Wakiso</option>
              <option value="Jinja">Jinja</option>
              <option value="Kololo">Kololo</option>
              <option value="Naguru">Naguru</option>
              <option value="Naalya">Naalya</option>
              <option value="Munyonyo">Munyonyo</option>
            </select>
          </div>

          {/* Property Type Dropdown */}
          <div className="flex-1 flex items-center px-4 border-b md:border-b-0 md:border-r border-gray-200 py-2 md:py-0">
            <Home className="text-gray-400 w-5 h-5 mr-3 shrink-0" />
            <select 
              className="w-full py-3 focus:outline-none text-gray-700 bg-transparent cursor-pointer"
              value={type}
              onChange={(e) => setType(e.target.value as FilterType)}
            >
              <option value="">Property Type</option>
              <option value={FilterType.SALE}>For Sale</option>
              <option value={FilterType.RENT}>For Rent</option>
              <option value={FilterType.LAND}>Land</option>
            </select>
          </div>

          <button 
            onClick={handleSearchClick}
            className="bg-hass-blue hover:bg-slate-800 text-white px-8 py-3 rounded-md font-semibold transition-colors shadow-md"
          >
            Search
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;