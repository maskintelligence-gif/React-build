import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://qmuuovbalclrxtblythc.supabase.co';
const supabaseKey = 'sb_publishable_-eQChPPGjegVjLfXQwPGuw_mAHvdsh_';

export const supabase = createClient(supabaseUrl, supabaseKey);