import { Property, PriceRangeOption } from './types';

export const EXCHANGE_RATE_USD_TO_UGX = 3750; // Current approximate rate

export const PROPERTIES: Property[] = [
  {
    id: '1',
    title: 'Luxury Villa in Kololo',
    price: 850000,
    currency: 'USD',
    location: 'Kololo, Kampala',
    bedrooms: 5,
    bathrooms: 6,
    sqft: 4500,
    type: 'Sale',
    category: 'Residential',
    imageUrl: 'https://picsum.photos/seed/kololo1/800/600',
    images: [
      'https://picsum.photos/seed/kololo1/800/600',
      'https://picsum.photos/seed/kololo_living/800/600',
      'https://picsum.photos/seed/kololo_kitchen/800/600',
      'https://picsum.photos/seed/kololo_bed/800/600',
      'https://picsum.photos/seed/kololo_pool/800/600'
    ],
    description: 'An exquisite 5-bedroom luxury villa located in the prestigious Kololo hill. Features a swimming pool, gym, and panoramic views of Kampala.',
    features: ['Swimming Pool', 'Gym', 'Garden', 'Security', 'Hill View']
  },
  {
    id: '2',
    title: 'Modern Apartment in Naguru',
    price: 2500,
    currency: 'USD',
    location: 'Naguru, Kampala',
    bedrooms: 3,
    bathrooms: 3,
    sqft: 1800,
    type: 'Rent',
    category: 'Residential',
    imageUrl: 'https://picsum.photos/seed/naguru2/800/600',
    images: [
      'https://picsum.photos/seed/naguru2/800/600',
      'https://picsum.photos/seed/naguru_living/800/600',
      'https://picsum.photos/seed/naguru_balcony/800/600'
    ],
    description: 'Fully furnished 3-bedroom apartment with modern amenities. Close to shopping malls and international schools.',
    features: ['Furnished', 'Balcony', 'Parking', 'WiFi', 'Generator']
  },
  {
    id: '3',
    title: 'Family Home in Naalya',
    price: 450000000,
    currency: 'UGX',
    location: 'Naalya, Wakiso',
    bedrooms: 4,
    bathrooms: 3,
    sqft: 2200,
    type: 'Sale',
    category: 'Residential',
    imageUrl: 'https://picsum.photos/seed/naalya3/800/600',
    images: [
      'https://picsum.photos/seed/naalya3/800/600',
      'https://picsum.photos/seed/naalya_compound/800/600',
      'https://picsum.photos/seed/naalya_int/800/600'
    ],
    description: 'A spacious family home in a secure gated community. Excellent access to the Northern Bypass.',
    features: ['Gated Community', 'Paved Compound', 'Boys Quarters', 'Garden']
  },
  {
    id: '4',
    title: 'Lake View Plot in Entebbe',
    price: 120000,
    currency: 'USD',
    location: 'Entebbe, Wakiso',
    bedrooms: 0,
    bathrooms: 0,
    sqft: 10890, // 25 decimals
    type: 'Sale',
    category: 'Land',
    imageUrl: 'https://picsum.photos/seed/entebbe4/800/600',
    description: 'Prime residential land with breathtaking views of Lake Victoria. Ideal for a resort or luxury home.',
    features: ['Lake View', 'Titled', 'Access Road', 'Electricity']
  },
  {
    id: '5',
    title: 'Commercial Space in CBD',
    price: 3500,
    currency: 'USD',
    location: 'Kampala Road, Kampala',
    bedrooms: 0,
    bathrooms: 2,
    sqft: 1500,
    type: 'Rent',
    category: 'Commercial',
    imageUrl: 'https://picsum.photos/seed/cbd5/800/600',
    images: [
        'https://picsum.photos/seed/cbd5/800/600',
        'https://picsum.photos/seed/cbd_interior/800/600'
    ],
    description: 'Premium office space in the heart of Kampala Business District. High foot traffic and visibility.',
    features: ['Elevator', 'Security', 'Backup Power', 'AC']
  },
  {
    id: '6',
    title: 'Cozy Bungalow in Munyonyo',
    price: 600000000,
    currency: 'UGX',
    location: 'Munyonyo, Kampala',
    bedrooms: 3,
    bathrooms: 2,
    sqft: 1600,
    type: 'Sale',
    category: 'Residential',
    imageUrl: 'https://picsum.photos/seed/munyonyo6/800/600',
    description: 'Walking distance to Speke Resort. A quiet and green neighborhood perfect for retirement or family living.',
    features: ['Garden', 'Perimeter Wall', 'Quiet Neighborhood', 'Water Tank']
  }
];

export const formatCurrency = (amount: number, currency: 'UGX' | 'USD') => {
  return new Intl.NumberFormat('en-UG', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

export const getConvertedPrice = (amount: number, fromCurrency: 'UGX' | 'USD'): { amount: number, currency: 'UGX' | 'USD' } => {
  if (fromCurrency === 'USD') {
    return { amount: amount * EXCHANGE_RATE_USD_TO_UGX, currency: 'UGX' };
  } else {
    return { amount: amount / EXCHANGE_RATE_USD_TO_UGX, currency: 'USD' };
  }
};

export const PRICE_RANGES: PriceRangeOption[] = [
  { label: 'Any Price', currency: 'UGX' }, // Default
  { label: 'Under 500M UGX', max: 500000000, currency: 'UGX' },
  { label: '500M - 1B UGX', min: 500000000, max: 1000000000, currency: 'UGX' },
  { label: '1B+ UGX', min: 1000000000, currency: 'UGX' },
  { label: 'Under $1,000 USD', max: 1000, currency: 'USD' },
  { label: '$1,000 - $5,000 USD', min: 1000, max: 5000, currency: 'USD' },
  { label: '$5,000+ USD', min: 5000, currency: 'USD' },
];