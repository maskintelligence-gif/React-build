export interface Property {
  id: string;
  title: string;
  price: number;
  currency: 'UGX' | 'USD';
  location: string;
  bedrooms: number;
  bathrooms: number;
  sqft: number;
  type: 'Sale' | 'Rent';
  category: 'Residential' | 'Commercial' | 'Land';
  imageUrl: string;
  images?: string[]; // Array of additional images for gallery
  description: string;
  features: string[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface PriceRangeOption {
  label: string;
  min?: number;
  max?: number;
  currency: 'UGX' | 'USD';
}

export enum FilterType {
  ALL = 'All',
  SALE = 'Sale',
  RENT = 'Rent',
  LAND = 'Land'
}