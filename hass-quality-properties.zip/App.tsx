import React, { useState, useEffect, useRef, useLayoutEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import PropertyList from './components/PropertyList';
import PropertyDetails from './components/PropertyDetails';
import AIAssistant from './components/AIAssistant';
import Footer from './components/Footer';
import AdminLogin from './components/AdminLogin';
import AdminDashboard from './components/AdminDashboard';
import { PROPERTIES, PRICE_RANGES } from './constants';
import { Property, FilterType } from './types';
import { supabase } from './lib/supabaseClient';

const App: React.FC = () => {
  // State for Navigation
  const [currentView, setCurrentView] = useState<'home' | 'details' | 'admin-login' | 'admin-dashboard'>('home');
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  
  // State for Data (Simulating DB with local state for now)
  const [properties, setProperties] = useState<Property[]>(PROPERTIES);
  
  // State for Filters
  const [filters, setFilters] = useState({
    keyword: '',
    location: '',
    type: FilterType.ALL,
    price: PRICE_RANGES[0]
  });

  // Auth State
  const [session, setSession] = useState<any>(null);

  // Scroll Restoration
  const scrollPositionRef = useRef(0);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session && currentView === 'admin-login') {
        setCurrentView('admin-dashboard');
      }
    });

    return () => subscription.unsubscribe();
  }, [currentView]);

  // Handle scroll restoration when view changes
  useLayoutEffect(() => {
    if (selectedProperty) {
      // When entering Details view, scroll to top instantly
      window.scrollTo(0, 0);
    } else {
      // When returning to Home/List view, restore previous scroll position
      if (scrollPositionRef.current > 0) {
        window.scrollTo(0, scrollPositionRef.current);
      }
    }
  }, [selectedProperty]);

  // Handler for Admin access trigger (Secret or Link)
  const handleAdminClick = () => {
    if (session) {
      setCurrentView('admin-dashboard');
    } else {
      setCurrentView('admin-login');
    }
  };

  const handleSearch = (searchFilters: { keyword: string; location: string; type: FilterType | '' }) => {
    setFilters(prev => ({
      ...prev,
      keyword: searchFilters.keyword,
      location: searchFilters.location,
      type: searchFilters.type === '' ? FilterType.ALL : searchFilters.type
    }));
  };

  const handleFilterChange = (newFilters: Partial<typeof filters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  // Determine if filters are active (to hide About Us)
  const isFiltering = filters.keyword !== '' || 
                      filters.location !== '' || 
                      filters.type !== FilterType.ALL || 
                      filters.price.label !== 'Any Price';

  // Render logic
  if (currentView === 'admin-login') {
    return (
      <AdminLogin 
        onLoginSuccess={() => setCurrentView('admin-dashboard')}
        onCancel={() => setCurrentView('home')}
      />
    );
  }

  if (currentView === 'admin-dashboard' && session) {
    return (
      <AdminDashboard 
        userEmail={session.user.email}
        properties={properties}
        onUpdateProperties={setProperties}
        onLogout={() => setCurrentView('home')}
      />
    );
  }

  // Public View
  return (
    <div className="min-h-screen flex flex-col font-sans text-slate-900">
      <Header />
      <main className="flex-grow">
        
        {selectedProperty ? (
           <PropertyDetails 
             property={selectedProperty} 
             onBack={() => {
                setSelectedProperty(null);
                // Scroll restoration is handled by useLayoutEffect
             }} 
           />
        ) : (
           <>
              <Hero onSearch={handleSearch} />
              
              {/* Value Proposition - Hides when filtering */}
              {!isFiltering && (
                <section id="about" className="py-16 bg-white animate-fade-in-up">
                    <div className="container mx-auto px-4">
                        <div className="flex flex-col md:flex-row gap-12 items-center">
                            <div className="w-full md:w-1/2">
                                <img 
                                    src="https://picsum.photos/seed/interior_design/800/600" 
                                    alt="Luxury Interior" 
                                    className="rounded-lg shadow-2xl"
                                />
                            </div>
                            <div className="w-full md:w-1/2">
                                <h2 className="text-3xl md:text-4xl font-serif font-bold text-hass-blue mb-6">
                                    Experience the Art of <span className="text-hass-gold">Living</span>
                                </h2>
                                <p className="text-gray-600 mb-6 leading-relaxed">
                                    At HASS QUALITY PROPERTIES, we believe that a home is more than just bricks and mortar; it's a reflection of your lifestyle and aspirations. Based in Kampala, we specialize in high-end residential and commercial real estate.
                                </p>
                                <div className="grid grid-cols-2 gap-6">
                                    <div className="border-l-4 border-hass-gold pl-4">
                                        <h4 className="font-bold text-xl text-slate-800">10+</h4>
                                        <p className="text-sm text-gray-500">Years Experience</p>
                                    </div>
                                    <div className="border-l-4 border-hass-gold pl-4">
                                        <h4 className="font-bold text-xl text-slate-800">500+</h4>
                                        <p className="text-sm text-gray-500">Properties Sold</p>
                                    </div>
                                    <div className="border-l-4 border-hass-gold pl-4">
                                        <h4 className="font-bold text-xl text-slate-800">100%</h4>
                                        <p className="text-sm text-gray-500">Client Satisfaction</p>
                                    </div>
                                    <div className="border-l-4 border-hass-gold pl-4">
                                        <h4 className="font-bold text-xl text-slate-800">24/7</h4>
                                        <p className="text-sm text-gray-500">Support</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
              )}

              <PropertyList 
                properties={properties} 
                onSelectProperty={(property) => {
                  scrollPositionRef.current = window.scrollY; // Capture current scroll position
                  setSelectedProperty(property);
                  // Scroll to top is handled by useLayoutEffect
                }}
                filters={filters}
                onFilterChange={handleFilterChange}
              />
              
              {/* Banner CTA - Hides when filtering for a cleaner look */}
              {!isFiltering && (
                <section className="bg-hass-blue py-20 relative overflow-hidden">
                    <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 bg-hass-gold opacity-10 rounded-full blur-3xl"></div>
                    <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 bg-hass-accent opacity-10 rounded-full blur-3xl"></div>
                    
                    <div className="container mx-auto px-4 text-center relative z-10">
                        <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">
                            Ready to Find Your <span className="text-hass-gold">Dream Home?</span>
                        </h2>
                        <p className="text-gray-300 text-lg mb-8 max-w-2xl mx-auto">
                            Contact our agents today or use our AI assistant to get started on your journey to home ownership.
                        </p>
                        <div className="flex flex-col sm:flex-row justify-center gap-4">
                            <a href="#contact" className="bg-hass-gold hover:bg-yellow-600 text-hass-blue px-8 py-3 rounded-full font-bold transition-all transform hover:scale-105">
                                Contact Sales
                            </a>
                            <button onClick={() => document.querySelector('button[aria-label="Open Support Chat"]')?.dispatchEvent(new MouseEvent('click', { bubbles: true }))} className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-hass-blue px-8 py-3 rounded-full font-bold transition-all">
                                Chat with AI
                            </button>
                        </div>
                    </div>
                </section>
              )}
           </>
        )}
      </main>
      
      {/* Footer with Admin Link injected */}
      <div className="bg-hass-blue border-t border-slate-800">
         <Footer />
         <div className="container mx-auto px-4 pb-4 text-center">
            <button 
                onClick={handleAdminClick} 
                className="text-slate-700 hover:text-hass-gold text-xs transition-colors"
            >
                Admin Access
            </button>
         </div>
      </div>
      
      {!selectedProperty && <AIAssistant />}
    </div>
  );
};

export default App;